
public class MyClass{
	
	private static String v1;
	
	public MyClass(){
		
	}

	public static String getV1() {
		return v1;
	}

	public static void setV1(String v1) {
		MyClass.v1 = v1;
	}
	
}